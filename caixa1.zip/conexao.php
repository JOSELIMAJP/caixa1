<?php
define('HOST', 'localhost');
define('USUARIO', 'id11247117_root2');
define('SENHA', '<K8%HJ>!(6ufopEY');
define('DB', 'id11247117_sisfinanceiro');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');